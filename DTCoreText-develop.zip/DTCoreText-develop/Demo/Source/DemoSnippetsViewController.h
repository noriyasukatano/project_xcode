//
//  DemoSnippetsViewController.h
//  DTCoreText
//
//  Created by Sam Soffes on 1/14/11.
//  Copyright 2011 Drobnik.com. All rights reserved.
//

@interface DemoSnippetsViewController : UITableViewController {

	NSArray *_snippets;
	
	NSCache *cellCache;
}

@end
